# MaskLab research record

**LIVE PROVIDER MEASUREMENTS**

Protocol SHA256: 7f97fc565140ac4224cf2a34f4f1819e815487522acc04f0f75c7bc8f0092b8b
Metric version: masklab-behavior-1

## Observations

Scheduled: 2430; finalized: 2430; valid: 2376; correct: 1582; failed: 0; uncertain: 0; pending: 0.
All-attempt correctness: 1582/2430; valid accuracy: 1582/2376.

## Methods and limitations

Roles and stated belief are crossed independently, with fresh conversations and frozen prompts. Decimal scoring is exact; invalid/refused/failed responses are non-correct finalized outcomes. Pending and uncertain outcomes are separate. Bootstrap uses 2,000 question-cluster resamples and 95% percentile intervals, with no interval below five eligible questions. See analysis.json for sample sizes, excluded pairs, seeds and sensitivity results.

- Convenience question set; no model-family or population-wide claims.
- Exploratory multiple comparisons; no corrected significance or interval-based ranking.
- Adoption is not proof of sycophancy or an internal causal mechanism.
- Repeated human tuning against held-out questions compromises confirmatory interpretation.
- Generated explanations are model output, not private reasoning or causal evidence.

No model-written interpretation is included. Negative and uncertain findings are retained.
