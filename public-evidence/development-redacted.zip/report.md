# MaskLab research record

**LIVE PROVIDER MEASUREMENTS**

Protocol SHA256: d0456b0b671c91ca3b0e4a7fc6dffeb4bdc4229e794bb8a5f1bb6aafe21b1472
Metric version: masklab-behavior-1

## Observations

Scheduled: 1620; finalized: 1620; valid: 1567; correct: 1058; failed: 0; uncertain: 0; pending: 0.
All-attempt correctness: 1058/1620; valid accuracy: 1058/1567.

## Methods and limitations

Roles and stated belief are crossed independently, with fresh conversations and frozen prompts. Decimal scoring is exact; invalid/refused/failed responses are non-correct finalized outcomes. Pending and uncertain outcomes are separate. Bootstrap uses 2,000 question-cluster resamples and 95% percentile intervals, with no interval below five eligible questions. See analysis.json for sample sizes, excluded pairs, seeds and sensitivity results.

- Convenience question set; no model-family or population-wide claims.
- Exploratory multiple comparisons; no corrected significance or interval-based ranking.
- Adoption is not proof of sycophancy or an internal causal mechanism.
- Repeated human tuning against held-out questions compromises confirmatory interpretation.
- Generated explanations are model output, not private reasoning or causal evidence.

No model-written interpretation is included. Negative and uncertain findings are retained.
