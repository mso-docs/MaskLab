# MaskLab research record

**LIVE PROVIDER MEASUREMENTS**

Protocol SHA256: 023027ad609fd69ab7ebc1ac8ac125a30466715ddbfd197588eafcbca61e7c9c
Metric version: masklab-behavior-1

## Observations

Scheduled: 648; finalized: 648; valid: 648; correct: 585; failed: 0; uncertain: 0; pending: 0.
All-attempt correctness: 585/648; valid accuracy: 585/648.

## Methods and limitations

Roles and stated belief are crossed independently, with fresh conversations and frozen prompts. Decimal scoring is exact; invalid/refused/failed responses are non-correct finalized outcomes. Pending and uncertain outcomes are separate. Bootstrap uses 2,000 question-cluster resamples and 95% percentile intervals, with no interval below five eligible questions. See analysis.json for sample sizes, excluded pairs, seeds and sensitivity results.

- Convenience question set; no model-family or population-wide claims.
- Exploratory multiple comparisons; no corrected significance or interval-based ranking.
- Adoption is not proof of sycophancy or an internal causal mechanism.
- Repeated human tuning against held-out questions compromises confirmatory interpretation.
- Generated explanations are model output, not private reasoning or causal evidence.

No model-written interpretation is included. Negative and uncertain findings are retained.
